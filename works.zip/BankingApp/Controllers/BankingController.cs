﻿using BankingLib;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace BankingApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BankingController : ControllerBase
    {
        private readonly ILogger<BankingController> _logger;
        public List<Customer>? CustList { get; set; }

        public BankingController(ILogger<BankingController> logger)
        {
            _logger = logger;
            FillData();
        }
        
        // GET: api/<BankingController>
        [HttpGet]
        public IEnumerable<Customer>? Get()
        {
            return CustList;
        }
        
        // GET api/<BankingController>/5
        [HttpGet("{id}")]
        public Customer? Get(int id)
        {
            return CustList?.Where(x => x.CustId == id)?.SingleOrDefault() as Customer;
        }

        // POST api/<BankingController>/5
        [HttpPost("{id}")]
        public void Post(int id, [FromBody] int acctNo)
        {
            Customer? cust = Get(id);
            if (cust != null)
            {
                cust.CreateNewAccount(acctNo);
            }
        }

        // PUT api/<BankingController>/5
        [HttpPut("{id}")]
        public void DepositOrWithdrawMoney(int id, [FromQuery] int acctNo,  [FromBody] decimal amount, [FromQuery] bool isDepositOrWithdraw = true)
        {
            Customer? cust = Get(id);
            if (cust != null)
            {
                BankAccount? acct = cust.BankAccounts.Where(x => x.AccountNumber == acctNo).SingleOrDefault() as BankAccount;
                if (acct != null)
                {
                    if (isDepositOrWithdraw)
                    {
                        acct.Deposit(amount);
                    }
                    else
                    {
                        acct.Withdraw(amount);
                    }
                }
            }
        }

        // DELETE api/<BankingController>/5
        [HttpDelete("{id}")]
        public void Delete(int id, [FromBody] int acctNo)
        {
            Customer? cust = Get(id);
            if (cust != null)
            {
                cust.DeleteAccount(acctNo);
            }
        }
       
        private void FillData()
        {
            List<BankAccount> bankAccountsforCust1 = new List<BankAccount>()
            {
                new BankAccount() { AccountNumber = 1, AmountToDeposit = 5000, AmountToWithdraw = 4000, CurrentBalance = 10000, MinBalance = 100 },
                new BankAccount() { AccountNumber = 2, AmountToDeposit = 6000, AmountToWithdraw = 3000, CurrentBalance = 9000, MinBalance = 100 },
            };
            List<BankAccount> bankAccountsforCust2 = new List<BankAccount>()
            {
                new BankAccount() { AccountNumber = 3, AmountToDeposit = 2000, AmountToWithdraw = 1000, CurrentBalance = 5000, MinBalance = 100 },
                new BankAccount() { AccountNumber = 4, AmountToDeposit = 3000, AmountToWithdraw = 4000, CurrentBalance = 7000, MinBalance = 100 },
            };
            List<BankAccount> bankAccountsforCust3 = new List<BankAccount>()
            {
                new BankAccount() { AccountNumber = 5, AmountToDeposit = 5000, AmountToWithdraw = 4000, CurrentBalance = 10000, MinBalance = 100 },
                new BankAccount() { AccountNumber = 6, AmountToDeposit = 6000, AmountToWithdraw = 3000, CurrentBalance = 9000, MinBalance = 100 },
            };
            CustList = new List<Customer>
            {
                new Customer { CustId = 1, BankAccounts = bankAccountsforCust1,},
                new Customer { CustId = 2, BankAccounts = bankAccountsforCust2,},
                new Customer { CustId = 3, BankAccounts = bankAccountsforCust3,},
            };
        }
    }
}
