﻿using BankingApp;
using BankingApp.Controllers;
using BankingLib;

namespace BankingLibTest
{
    public class UnitTest2
    {
        BankingController controller = new BankingController(null);
        [Fact]
        public void TestPostMethod()
        {
            int id = 1, acctNo = 10;
            controller.Post(id, acctNo);
            Customer? cust = controller.CustList?.Where(x => x.CustId == id).FirstOrDefault() as Customer;
            Assert.Single(cust?.BankAccounts, cust?.BankAccounts?.Where(x => x.AccountNumber == acctNo).SingleOrDefault());
        }
        [Fact]
        public void TestDeleteMethod()
        {
            int id = 1, acctNo = 2;
            controller.Delete(id, acctNo);
            Customer? cust = controller.CustList?.Where(x => x.CustId == id).FirstOrDefault() as Customer;
            Assert.False(cust?.BankAccounts?.Any(x => x.AccountNumber == 2));
        }
        [Fact]
        public void TestDepositMoney()
        {
            int id = 1, acctNo = 2;
            decimal amt = 5000;
            bool isDepositOrWithdraw = true;
            controller.DepositOrWithdrawMoney(id, acctNo, amt, isDepositOrWithdraw);
            Customer? cust = controller.CustList?.Where(x => x.CustId == id).FirstOrDefault() as Customer;
            BankAccount? acct = cust?.BankAccounts?.Where(x => x.AccountNumber == acctNo).FirstOrDefault() as BankAccount;
            Assert.Equal(14000, acct?.CurrentBalance);
        }
        [Fact]
        public void TestWithdrawMoney()
        {
            int id = 1, acctNo = 2;
            decimal amt = 5000;
            bool isDepositOrWithdraw = false;
            controller.DepositOrWithdrawMoney(id, acctNo, amt, isDepositOrWithdraw);
            Customer? cust = controller.CustList?.Where(x => x.CustId == id).FirstOrDefault() as Customer;
            BankAccount? acct = cust?.BankAccounts?.Where(x => x.AccountNumber == acctNo).FirstOrDefault() as BankAccount;
            Assert.Equal(4000, acct?.CurrentBalance);
        }
    }
}
