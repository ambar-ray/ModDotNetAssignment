using BankingLib;

namespace BankingLibTest
{
    public class UnitTest1
    {
        [Fact]
        public void TestWithdrawAmount()
        {
            BankAccount acct = new BankAccount { AccountNumber = 10, AmountToDeposit = 0, AmountToWithdraw = 0, CurrentBalance = 1000, MinBalance = 100};
            decimal currBal = acct.Withdraw(600);
            Assert.Equal(400, currBal);
        }
        [Fact]
        public void TestWithdrawMoreThanNinetyPercent()
        {
            BankAccount acct = new BankAccount { AccountNumber = 10, AmountToDeposit = 0, AmountToWithdraw = 0, CurrentBalance = 2000, MinBalance = 100 };
            Assert.Throws<InvalidOperationException>(() => acct.Withdraw(1850));
        }
        [Fact]
        public void TestWithdrawWithLessThanHundredBalance()
        {
            BankAccount acct = new BankAccount { AccountNumber = 10, AmountToDeposit = 0, AmountToWithdraw = 0, CurrentBalance = 2000, MinBalance = 100 };
            Assert.Throws<ArgumentException>(() => acct.Withdraw(1950));
        }
        [Fact]
        public void TestDepositAccount()
        {
            BankAccount acct = new BankAccount { AccountNumber = 10, AmountToDeposit = 0, AmountToWithdraw = 0, CurrentBalance = 2000, MinBalance = 100 };
            decimal currBal = acct.Deposit(1000);
            Assert.Equal(3000, currBal);
        }
        [Fact]
        public void TestDepositAccountMoreThanTenThousand()
        {
            BankAccount acct = new BankAccount { AccountNumber = 10, AmountToDeposit = 0, AmountToWithdraw = 0, CurrentBalance = 2000, MinBalance = 100 };
            Assert.Throws<InvalidOperationException>(() => acct.Deposit(15000));
        }
        [Fact]
        public void CustomerCanCreateAccount()
        {
            Customer customer = new Customer();
            customer.CreateNewAccount(10);
            Assert.Single(customer.BankAccounts, customer.BankAccounts.Where(x => x.AccountNumber == 10).SingleOrDefault());
        }
        [Fact]
        public void CustomerCanDeleteAccount()
        {
            Customer customer = new Customer();
            customer.CreateNewAccount(10);
            customer.DeleteAccount(10);
            Assert.False(customer.BankAccounts?.Any(x => x.AccountNumber == 10));
        }
    }
}