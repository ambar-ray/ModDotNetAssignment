﻿namespace BankingLib
{
    public class BankAccount
    {
        
        public BankAccount() { }
        public int AccountNumber { get; set; }
        public decimal MinBalance { get; set; } = 100;
        public decimal CurrentBalance { get; set; }
        public decimal AmountToDeposit {  get; set; }
        public decimal AmountToWithdraw { get; set; }

        public decimal Withdraw(decimal amount)
        {
           
            if ((CurrentBalance - amount) < 100)
            {
                throw new ArgumentException("A minimum balance of $100 has to be maintained");
            }
            else if (amount > (0.9M * CurrentBalance))
            {
                throw new InvalidOperationException("A user cannot withdraw more than 90% of their total balance from an\r\naccount in a single transaction");
            }
            else
            {
                CurrentBalance -= amount;
            }
            
            return CurrentBalance;
        }

        public decimal Deposit(decimal amount)
        {
            if (amount > 10000)
            {
                throw new InvalidOperationException("A user cannot deposit more than $10,000 in a single transaction");
            }
            else
            {
                CurrentBalance += amount;
            }
            return CurrentBalance;
        }
    }
}
