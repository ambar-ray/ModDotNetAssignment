﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankingLib
{
    public class Customer
    {
        public int CustId { get; set; }
        public List<BankAccount>? BankAccounts { get; set; } = null;

        public Customer() 
        {
            BankAccounts = new List<BankAccount>();
        }

        public BankAccount CreateNewAccount(int acctNo)
        {
            if (BankAccounts == null)
            {
                BankAccounts = new List<BankAccount>();
            }
            var account = new BankAccount();
            account.AccountNumber = acctNo;
            BankAccounts.Add(account);
            return account;
        }
        public BankAccount DeleteAccount(int accountNumber)
        {
            var account = BankAccounts?.Where(x => x.AccountNumber == accountNumber).SingleOrDefault() as BankAccount;
            if (account != null)
            {
                BankAccounts?.Remove(account);
            }
            else
            {
                Console.WriteLine("No such account exist");
                throw new InvalidOperationException("No such account exist");
            }
            return account;
        }
    }
}

